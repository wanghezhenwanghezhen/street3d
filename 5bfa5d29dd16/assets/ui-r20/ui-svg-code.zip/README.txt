Layered HUD: play=reference1, edit=reference2, interaction=reference3.
SVG icon layers can be replaced independently.
Dice is a rounded dimpled Three.js mesh, not a raster image.
Use modules in the existing game; npm/browser import map must provide three.
Motion is a web adaptation inspired by the official Splatoon page, not UE code.
